﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InventoryManagementSystem.pictures
{
    public partial class ViewOrders : Form
    {
        public ViewOrders()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\swathy_b587\Documents\InventoryDb.mdf;Integrated Security=True;Connect Timeout=30");
        void populateOrders()
        {
            try
            {
                con.Open();
                String myquery = "select * from OrderTbl order by OrderId";
                SqlDataAdapter da = new SqlDataAdapter(myquery, con);
                SqlCommandBuilder builder = new SqlCommandBuilder(da);
                var ds = new DataSet();
                da.Fill(ds);
                OrderGv.DataSource = ds.Tables[0];
                con.Close();
            }
            catch
            {

            }
        }
        private void ViewOrders_Load(object sender, EventArgs e)
        {
            OrderGv.ColumnHeadersDefaultCellStyle.BackColor = Color.DarkGreen;
            OrderGv.ColumnHeadersDefaultCellStyle.SelectionBackColor = Color.DarkGreen;
            OrderGv.DefaultCellStyle.SelectionBackColor = Color.LightCoral;
            OrderGv.EnableHeadersVisualStyles = false;
            populateOrders();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();

        }

        private void label10_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
