﻿using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace InventoryManagementSystem
{
    public partial class ManageUsers : Form
    {
        public ManageUsers()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\swathy_b587\Documents\InventoryDb.mdf;Integrated Security=True;Connect Timeout=30");
        void populate()
        { 
            con.Open();
            String myquery = "select * from UserTbl order by Uname";
            SqlDataAdapter da =new SqlDataAdapter(myquery,con);
            SqlCommandBuilder builder= new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            usersGv.DataSource= ds.Tables[0];
            con.Close();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            

            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("insert into UserTbl values('" + unameTb.Text + "','" + fnameTb.Text + "','" + passwordTb.Text + "','" + mobileTb.Text + "')", con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("User Successfully Added");
                con.Close();
                populate();
            }
            catch
            { 

            }
        }

        private void label7_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

            private void ManageUsers_Load(object sender, EventArgs e)
        {
            populate();
            usersGv.ColumnHeadersDefaultCellStyle.BackColor = Color.Crimson;
            usersGv.ColumnHeadersDefaultCellStyle.SelectionBackColor = Color.Crimson;
            usersGv.DefaultCellStyle.SelectionBackColor = Color.LightCoral;
            usersGv.EnableHeadersVisualStyles = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (mobileTb.Text == "")
            {

                MessageBox.Show("Please enter the user's phone number");

            }
            else
            {
                con.Open();
                string myquery = "delete from UserTbl where Uphone='" + mobileTb.Text + "'";
                SqlCommand cmd = new SqlCommand(myquery,con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("user data deleted successfully!");
                con.Close();
                populate();
                unameTb.Text = "";
                fnameTb.Text = "";
                passwordTb.Text = "";
                mobileTb.Text = "";
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            usersGv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            unameTb.Text = usersGv.SelectedRows[0].Cells[0].Value.ToString();
            fnameTb.Text = usersGv.SelectedRows[0].Cells[1].Value.ToString();
            passwordTb.Text = usersGv.SelectedRows[0].Cells[2].Value.ToString();
            mobileTb.Text = usersGv.SelectedRows[0].Cells[3].Value.ToString();
          
        }

        private void button2_Click(object sender, EventArgs e)
        {

                con.Open();
                SqlCommand cmd = new SqlCommand("update UserTbl set Uname='" + unameTb.Text + "',Ufullname='" + fnameTb.Text + "',Upassword='" + passwordTb.Text + "'where Uphone='" + mobileTb.Text + "'", con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("User Successfully Updated!");
                con.Close();
                populate();
           
        }

        private void button5_Click(object sender, EventArgs e)
        {
            unameTb.Text = "";
            fnameTb.Text = "";
            passwordTb.Text = "";
            mobileTb.Text = "";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            HomePage home = new HomePage();
            home.Show();
            this.Hide();
        }
    }
}
