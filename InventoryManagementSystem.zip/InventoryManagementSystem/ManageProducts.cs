﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InventoryManagementSystem
{

    public partial class ManageProducts : Form
    {
        public ManageProducts()
        {
            InitializeComponent();
        }

        SqlConnection con =new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\swathy_b587\\Documents\\InventoryDb.mdf;Integrated Security=True;Connect Timeout=30");

        void populate()
        {
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter("Select * from ProductTbl",con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds=new DataSet();
            da.Fill(ds);
            productsGv.DataSource = ds.Tables[0];
            con.Close();
        }
        void fillbyCategory()
        {
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter("Select * from ProductTbl where ProdCat='"+searchCombo.SelectedValue.ToString()+"'", con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            productsGv.DataSource = ds.Tables[0];
            con.Close();
        }
        void fillcategory()
        {
            string query = "Select * from CategoryTbl";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader rdr;
            try
            { 
                con.Open();
                DataTable dt = new DataTable();
                dt.Columns.Add("CatName", typeof(string));
                rdr=cmd.ExecuteReader();
                dt.Load(rdr);
                CategoryCombo.ValueMember = "CatName";
                CategoryCombo.DataSource = dt;
                searchCombo.ValueMember = "CatName";
                searchCombo.DataSource = dt;
                con.Close();
            }
            catch 
            { 

            }

        }
       
        private void ManageProducts_Load(object sender, EventArgs e)
        {
            fillcategory();
            populate();
            
            productsGv.ColumnHeadersDefaultCellStyle.BackColor = Color.Crimson;
            productsGv.ColumnHeadersDefaultCellStyle.SelectionBackColor = Color.Crimson;
            productsGv.DefaultCellStyle.SelectionBackColor = Color.LightCoral;
            productsGv.EnableHeadersVisualStyles = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into ProductTbl values('"+prodIdTb.Text +"','"+ prodNameTb.Text+ "','"+ prodQtyTb.Text+ "','"+ prodPriceTb.Text+ "','"+ prodDescTb.Text+ "','"+ CategoryCombo.SelectedValue.ToString()+ "') ",con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Product Successfully Added");
            con.Close();
            populate();

        }

        private void label10_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("delete from ProductTbl where ProdId='"+prodIdTb.Text+"'",con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Product has deleted Successfully!");
            con.Close();
            populate();
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            
            prodIdTb.Text = "";
            prodNameTb.Text = "";
            prodQtyTb.Text = "";
            prodPriceTb.Text = "";
            prodDescTb.Text = "";
        }

        private void productsGv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            productsGv.SelectionMode =DataGridViewSelectionMode.FullRowSelect;
            prodIdTb.Text = productsGv.SelectedRows[0].Cells[0].Value.ToString();
            prodNameTb.Text = productsGv.SelectedRows[0].Cells[1].Value.ToString();
            prodQtyTb.Text = productsGv.SelectedRows[0].Cells[2].Value.ToString();
            prodPriceTb.Text = productsGv.SelectedRows[0].Cells[3].Value.ToString();
            prodDescTb.Text = productsGv.SelectedRows[0].Cells[4].Value.ToString();
            CategoryCombo.SelectedValue = productsGv.SelectedRows[0].Cells[5].Value.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("update ProductTbl set ProdId='" + prodIdTb.Text + "',ProdName='" + prodNameTb.Text + "',ProdQty='" + prodQtyTb.Text + "',ProdPrice='"+prodPriceTb.Text+"',ProdDesc='"+prodDescTb.Text+"',ProdCat='"+ CategoryCombo.SelectedValue.ToString() + "'where ProdId='" + prodIdTb.Text + "'", con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Product data Successfully Updated!");
            con.Close();
            populate();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            //Button refreshButton = new Button();
            //refreshButton.Text = "";
            ////refreshButton.Image = Image.FromFile("refresh.png");
            //refreshButton.BackColor = Color.Red;
            //refreshButton.ForeColor = Color.White;
            //refreshButton.Size = new Size(32, 32);
            ////refreshButton.Click += RefreshButton_Click;
            fillbyCategory();
        }

        private void refreshButton_Click(object sender, EventArgs e)
        {
            populate();
        }

        private void searchCombo_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            HomePage home = new HomePage();
            home.Show();
            this.Hide();
        }
    }
}
