﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InventoryManagementSystem
{
    public partial class ManageCategories : Form
    {
        public ManageCategories()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\swathy_b587\Documents\InventoryDb.mdf;Integrated Security=True;Connect Timeout=30");
        void populate()
        {
            con.Open();
            String myquery = "select * from CategoryTbl order by CatId";
            SqlDataAdapter da = new SqlDataAdapter(myquery, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            categoryGv.DataSource = ds.Tables[0];
            con.Close();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            catIdTb.Text = "";
            catNameTb.Text = "";
        }

        private void categoryGv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            categoryGv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            catIdTb.Text = categoryGv.SelectedRows[0].Cells[0].Value.ToString();
            catNameTb.Text = categoryGv.SelectedRows[0].Cells[1].Value.ToString();
           
        }

        private void button2_Click(object sender, EventArgs e)
        {

            con.Open();
            SqlCommand cmd = new SqlCommand("update CategoryTbl set CatId='" + catIdTb.Text + "',CatName='" + catNameTb.Text + "'where CatId='" + catIdTb.Text + "'", con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Category Successfully Updated!");
            con.Close();
            populate();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("insert into CategoryTbl values('" + catIdTb.Text + "','" + catNameTb.Text + "')", con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Category Successfully Added");
                con.Close();
                populate();
            }
            catch
            {

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (catIdTb.Text == "")
            {

                MessageBox.Show("Please enter the user's phone number");

            }
            else
            {
                con.Open();
                string myquery = "delete from CategoryTbl where catId='" + catIdTb.Text + "'";
                SqlCommand cmd = new SqlCommand(myquery, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Category data deleted successfully!");
                con.Close();
                populate();
                catIdTb.Text = "";
                catNameTb.Text = "";
              

            }
        }

        private void ManageCategories_Load(object sender, EventArgs e)
        {
            populate();
            categoryGv.ColumnHeadersDefaultCellStyle.BackColor = Color.Crimson;
            categoryGv.ColumnHeadersDefaultCellStyle.SelectionBackColor = Color.Crimson;
            categoryGv.DefaultCellStyle.SelectionBackColor = Color.LightCoral;
            categoryGv.EnableHeadersVisualStyles = false;
        }

        private void label3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            HomePage home = new HomePage();
            home.Show();
            this.Hide();
        }
    }
}
