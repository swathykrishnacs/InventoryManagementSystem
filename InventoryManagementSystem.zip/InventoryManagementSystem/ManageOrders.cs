﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Drawing.Text;
using System.Drawing.Imaging;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using InventoryManagementSystem.pictures;

namespace InventoryManagementSystem
{
    public partial class ManageOrders : Form
    {
        private int count = 0;
        int numberOfRows = 0;
        int flag = 0;
        int num = 0;
        string product;
        int uprice, totalprice, quantity,stock;
        DataTable table = new DataTable();
        
        public ManageOrders()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\swathy_b587\Documents\InventoryDb.mdf;Integrated Security=True;Connect Timeout=30");

        private void ManageOrders_Load(object sender, EventArgs e)
        {
            populate();
            populateProducts();
            fillcategory();
            addbtn.Font = new Font(addbtn.Font.FontFamily, 8);
            dateTimePicker1.BackColor = Color.Crimson;
            dateTimePicker1.ForeColor = Color.White;
            CustomersGv.ColumnHeadersDefaultCellStyle.BackColor = Color.Crimson;
            CustomersGv.ColumnHeadersDefaultCellStyle.SelectionBackColor = Color.Crimson;
            CustomersGv.DefaultCellStyle.SelectionBackColor = Color.LightCoral;
            CustomersGv.EnableHeadersVisualStyles = false;
            CategoryGv.ColumnHeadersDefaultCellStyle.BackColor = Color.Crimson;
            CategoryGv.ColumnHeadersDefaultCellStyle.SelectionBackColor = Color.Crimson;
            CategoryGv.DefaultCellStyle.SelectionBackColor = Color.LightCoral;
            CategoryGv.EnableHeadersVisualStyles = false;
            OrderGv.ColumnHeadersDefaultCellStyle.BackColor = Color.Crimson;
            OrderGv.ColumnHeadersDefaultCellStyle.SelectionBackColor = Color.Crimson;
            OrderGv.DefaultCellStyle.SelectionBackColor = Color.LightCoral;
            OrderGv.EnableHeadersVisualStyles = false;

            table.Columns.Add("Num", typeof(int));
            table.Columns.Add("Product", typeof(string));
            table.Columns.Add("Quantity", typeof(int));
            table.Columns.Add("Uprice", typeof(int));
            table.Columns.Add("Totalprice", typeof(int));

            con.Open();
            SqlCommand command = new SqlCommand("SELECT MAX(OrderId) FROM OrderTbl;", con);
            object result = command.ExecuteScalar();
            if (result != null && result != DBNull.Value)
            {
                int lastInsertedID = Convert.ToInt32(result) + 1;
                orderId.Text = lastInsertedID.ToString();
            }
            else
            {
                orderId.Text = "10001";
            }
            con.Close();
        }
        void populate()
        {
            con.Open();
            String myquery = "select * from CustomerTbl order by custId";
            SqlDataAdapter da = new SqlDataAdapter(myquery, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            CustomersGv.DataSource = ds.Tables[0];
            con.Close();
        }
        void populateProducts()
        {
            con.Open();
            String myquery = "select * from ProductTbl order by ProdId";
            SqlDataAdapter da = new SqlDataAdapter(myquery, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            CategoryGv.DataSource = ds.Tables[0];
            con.Close();
        }
        void fillcategory()
        {
            string query = "Select * from CategoryTbl";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader rdr;
            try
            {
                con.Open();
                DataTable dt = new DataTable();
                dt.Columns.Add("CatName", typeof(string));
                rdr = cmd.ExecuteReader();
                dt.Load(rdr);
                CategoryCombo.ValueMember = "CatName";
                CategoryCombo.DataSource = dt;
                con.Close();
            }
            catch
            {

            }

        }
        void updateProduct()
        {
            con.Open();
            int id = Convert.ToInt32(CategoryGv.SelectedRows[0].Cells[0].Value.ToString());
            int newQty = stock-Convert.ToInt32(quantityTb.Text);
            string query = "Update ProductTbl set ProdQty="+ newQty  +" where ProdId="+ id +";";
            SqlCommand cmd = new SqlCommand(query,con);
            cmd.ExecuteNonQuery();
            con.Close();
            populateProducts();
        }
        void fillbyCategory()
        {
            //con.Open();
            SqlDataAdapter da = new SqlDataAdapter("Select * from ProductTbl where ProdCat='" + CategoryCombo.SelectedValue.ToString() + "'", con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            CategoryGv.DataSource = ds.Tables[0];
            con.Close();
        }
        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void CustomersGv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            custId.Text = CustomersGv.SelectedRows[0].Cells[0].Value.ToString();
            custName.Text = CustomersGv.SelectedRows[0].Cells[1].Value.ToString();

        }
        
     
        private void CategoryGv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            flag = 1;
            if (e.RowIndex >= 0)
            {
                CategoryGv.Rows[e.RowIndex].Selected = true;
            }
            product = CategoryGv.SelectedRows[0].Cells[1].Value.ToString();
            uprice = Convert.ToInt32(CategoryGv.SelectedRows[0].Cells[3].Value.ToString());
            stock = Convert.ToInt32(CategoryGv.SelectedRows[0].Cells[2].Value.ToString());
        }
        int j = 0;
        int sum = 0;

        private void button1_Click(object sender, EventArgs e)
        {
            if (orderId.Text == "" || custId.Text == "" || custName.Text == "")
            {
                MessageBox.Show("Enter all fields!");
            }
            else
            {
                con.Open();
                //int total;
                //int.TryParse(totalAmountLbl.Text, out total);
                SqlCommand cmd = new SqlCommand("insert into OrderTbl values('" + orderId.Text + "','" + custId.Text + "','" + custName.Text + "','" + dateTimePicker1.Text + "','"+sum+"') ", con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Order Successfully Placed");
                con.Close();
                populate();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {

            HomePage home = new HomePage();
            home.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ViewOrders view = new ViewOrders();
            view.Show();
        }

        private void addbtn_Click(object sender, EventArgs e)
        {
            j++;
            count++;
           // int i = j; 
            numberOfRows = count;

            DataRow[] dr = new DataRow[numberOfRows+1];




            if (quantityTb.Text == "")
            {
                MessageBox.Show("Enter Quantity of products!");
                //count--;
                //numberOfRows = count;
                //populateProducts();
                return;

            }
            else if (flag == 0)
            {
                MessageBox.Show("Select the product!");
                return;

            }
            else if(Convert.ToInt32(quantityTb.Text)>stock)
            {
                MessageBox.Show("Stock not Available!");
                return;

            }
            else
            {


                for (int i = j; i <= numberOfRows; i++)
                {
                    //num = i;
                    quantity = Convert.ToInt32(quantityTb.Text);
                    totalprice = quantity * uprice;
                    dr[i] = table.NewRow();
                    dr[i]["Num"] = i;
                    dr[i]["Product"] = product;
                    dr[i]["Quantity"] = quantity;
                    dr[i]["Uprice"] = uprice;
                    dr[i]["Totalprice"] = totalprice;
                    table.Rows.Add(dr[i]);
                }
                OrderGv.DataSource = table;

            }
            sum = sum + totalprice;
            totalAmountLbl.Text = "Rs." + sum.ToString();
            updateProduct();
        }

        private void label10_Click(object sender, EventArgs e)
        {
                Application.Exit();
        }

        private void CategoryCombo_SelectedIndexChanged(object sender, EventArgs e)
        {
                fillbyCategory();
        }
        
    }
}
