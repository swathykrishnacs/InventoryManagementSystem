﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InventoryManagementSystem
{
    public partial class ManageCustomers : Form
    {
        public ManageCustomers()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\swathy_b587\Documents\InventoryDb.mdf;Integrated Security=True;Connect Timeout=30");

        void populate()
        {
            con.Open();
            String myquery = "select * from CustomerTbl order by custId";
            SqlDataAdapter da = new SqlDataAdapter(myquery, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            customersGv.DataSource = ds.Tables[0];
            con.Close();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("insert into CustomerTbl values('" + customerIdTb.Text + "','" + customerNameTb.Text + "','" + customerPhoneTb.Text + "')", con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Customer Successfully Added");
                con.Close();
                populate();
            }
            catch
            {

            }
        }

        private void ManageCustomers_Load(object sender, EventArgs e)
        {
            populate();
            customersGv.ColumnHeadersDefaultCellStyle.BackColor = Color.Crimson;
            customersGv.ColumnHeadersDefaultCellStyle.SelectionBackColor = Color.Crimson;
            customersGv.DefaultCellStyle.SelectionBackColor = Color.LightCoral;
            customersGv.EnableHeadersVisualStyles = false;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            customerIdTb.Text = "";
            customerNameTb.Text = "";
            customerPhoneTb.Text = "";
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("update CustomerTbl set custId='" + customerIdTb.Text + "',custName='" + customerNameTb.Text + "',custPhone='" + customerPhoneTb.Text + "'where custId='" + customerIdTb.Text + "'", con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Customer Successfully Updated!");
            con.Close();
            populate();
        }

        private void customersGv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            customersGv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            customerIdTb.Text = customersGv.SelectedRows[0].Cells[0].Value.ToString();
            customerNameTb.Text = customersGv.SelectedRows[0].Cells[1].Value.ToString();
            customerPhoneTb.Text = customersGv.SelectedRows[0].Cells[2].Value.ToString();

            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select Count(*) from OrderTbl where CustId="+ customerIdTb .Text+ "",con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            OrderLbl.Text = dt.Rows[0][0].ToString();

            SqlDataAdapter sda1 = new SqlDataAdapter("Select Sum(TotalAmount) from OrderTbl where CustId=" + customerIdTb.Text + "", con);
            DataTable dt1 = new DataTable();
            sda1.Fill(dt1);
            OrderAmntLbl.Text = dt1.Rows[0][0].ToString();

            try
            {
                SqlDataAdapter sda2 = new SqlDataAdapter("Select OrderDate from OrderTbl where CustId=" + customerIdTb.Text + "", con);
                DataTable dt2 = new DataTable();
                sda2.Fill(dt2);
                OrderDateLbl.Text = dt2.Rows[0][0].ToString();
                con.Close();
            }
            catch 
            {
                MessageBox.Show("No order yet");
            }
            
             
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (customerIdTb.Text == "")
            {

                MessageBox.Show("Please enter the customer Id");

            }
            else
            {
                con.Open();
                string myquery = "delete from CustomerTbl where custId='" + customerIdTb.Text + "'";
                SqlCommand cmd = new SqlCommand(myquery, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Customer data deleted successfully!");
                con.Close();
                populate();
                customerIdTb.Text = "";
                customerNameTb.Text = "";
                customerPhoneTb.Text = "";
                
            }
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            HomePage home = new HomePage();
            home.Show();
            this.Hide();
        }
    }
}
